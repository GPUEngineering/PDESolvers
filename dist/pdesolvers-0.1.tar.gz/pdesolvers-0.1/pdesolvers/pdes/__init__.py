from .heat_1d import HeatEquation
from .black_scholes import BlackScholesEquation